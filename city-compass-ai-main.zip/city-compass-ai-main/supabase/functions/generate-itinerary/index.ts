import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { destination, days, budget, interests, latitude, longitude } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY not configured");

    const systemPrompt = `You are an expert travel planner specializing in Indian tourism. Generate detailed day-by-day itineraries. 
All budgets must be in Indian Rupees (₹). Be specific with real place names, timings, and estimated costs.
Format each day clearly with Morning, Afternoon, Evening sections. Include restaurant recommendations with cuisine type and price range.`;

    const userPrompt = `Create a ${days}-day travel itinerary for ${destination}.
Budget level: ${budget}
Interests: ${interests.join(", ")}
${latitude && longitude ? `User is currently at latitude ${latitude}, longitude ${longitude}.` : ""}

Format:
📅 Day X
🌅 Morning: [activity with specific place name]
🍽️ Lunch: [restaurant recommendation with cuisine and price in ₹]
🏛️ Afternoon: [activity with specific place name]
🍽️ Dinner: [restaurant recommendation with cuisine and price in ₹]
🌙 Evening: [activity]
💰 Estimated daily budget: ₹X,XXX - ₹X,XXX

Provide real, accurate place names and costs for ${destination}.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        stream: false,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again shortly." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted. Please add funds." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errText = await response.text();
      console.error("AI gateway error:", response.status, errText);
      throw new Error("AI gateway error");
    }

    const data = await response.json();
    const itinerary = data.choices?.[0]?.message?.content || "";

    return new Response(JSON.stringify({ itinerary }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("generate-itinerary error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
